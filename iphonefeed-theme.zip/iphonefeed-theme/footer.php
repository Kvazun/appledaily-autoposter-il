<!-- Footer -->
<footer class="bg-surface-container-low mt-20 border-t border-outline-variant/20">
    <div class="flex flex-col md:flex-row justify-between items-center w-full px-8 md:px-12 py-12 gap-8 max-w-screen-2xl mx-auto">
        <div class="flex flex-col gap-3 items-center md:items-start">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="font-headline text-2xl font-semibold text-on-surface tracking-tighter">
                <?php bloginfo('name'); ?>
            </a>
            <p class="font-body text-xs text-on-surface-variant/60 max-w-xs text-center md:text-left">
                <?php bloginfo('description'); ?>
            </p>
        </div>
        <div class="flex flex-wrap justify-center gap-6">
            <?php
            $cats = get_categories(['number' => 5, 'hide_empty' => true]);
            foreach ($cats as $cat):
            ?>
            <a class="text-on-surface/50 font-body text-sm hover:text-primary transition-all duration-300" href="<?php echo esc_url(get_category_link($cat->term_id)); ?>">
                <?php echo esc_html($cat->name); ?>
            </a>
            <?php endforeach; ?>
        </div>
        <div class="text-on-surface/40 font-body text-[10px] uppercase tracking-widest text-center md:text-right">
            &copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>.<br>
            <span class="opacity-50">Все права защищены.</span>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
