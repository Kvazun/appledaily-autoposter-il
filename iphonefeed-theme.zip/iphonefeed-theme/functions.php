<?php
if (!defined('ABSPATH')) exit;

/* ── Theme Setup ── */
function iphonefeed_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form','comment-form','comment-list','gallery','caption']);
    add_theme_support('custom-logo');
    add_image_size('hero', 1200, 900, true);
    add_image_size('card', 600, 450, true);
    register_nav_menus(['primary' => 'Primary Menu']);
}
add_action('after_setup_theme', 'iphonefeed_setup');

/* ── Enqueue Styles ── */
function iphonefeed_styles() {
    wp_enqueue_style('iphonefeed-style', get_stylesheet_uri(), [], '1.0');
}
add_action('wp_enqueue_scripts', 'iphonefeed_styles');

/* ── Inject Tailwind + Fonts via wp_head ── */
function iphonefeed_head_scripts() {
?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Newsreader:ital,opsz,wght@0,6..72,200..800;1,6..72,200..800&family=Inter:wght@300;400;500;600;700&family=Space+Grotesk:wght@300..700&family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com?plugins=forms"></script>
<script>
tailwind.config = {
    theme: {
        extend: {
            colors: {
                "primary": "#a43716",
                "primary-container": "#c54f2c",
                "on-primary": "#ffffff",
                "surface": "#fcf9f4",
                "surface-container": "#f0ede8",
                "surface-container-high": "#ebe8e3",
                "surface-container-highest": "#e5e2dd",
                "surface-container-low": "#f6f3ee",
                "on-surface": "#1c1c19",
                "on-surface-variant": "#58423c",
                "secondary-container": "#eae1d7",
                "on-secondary-container": "#69635c",
                "outline-variant": "#dfc0b7",
                "outline": "#8b716a",
                "inverse-surface": "#31302d",
                "inverse-on-surface": "#f3f0eb",
            },
            fontFamily: {
                "headline": ["Newsreader", "Georgia", "serif"],
                "body": ["Inter", "system-ui", "sans-serif"],
                "label": ["Space Grotesk", "system-ui", "sans-serif"],
            },
        },
    },
}
</script>
<?php
}
add_action('wp_head', 'iphonefeed_head_scripts', 1);

/* ── Reading Time Helper ── */
function iphonefeed_reading_time($post_id = null) {
    $content = get_post_field('post_content', $post_id ?: get_the_ID());
    $word_count = str_word_count(strip_tags($content));
    $minutes = max(1, ceil($word_count / 200));
    return $minutes . ' мин';
}

/* ── Category Badge Helper ── */
function iphonefeed_category_badge($post_id = null) {
    $cats = get_the_category($post_id ?: get_the_ID());
    if (!empty($cats)) {
        $name = esc_html($cats[0]->name);
        $link = esc_url(get_category_link($cats[0]->term_id));
        echo '<a href="' . $link . '" class="font-label text-[10px] uppercase tracking-widest text-primary mb-3 block hover:underline">' . $name . '</a>';
    }
}

/* ── Post Thumbnail with Fallback ── */
function iphonefeed_thumbnail($size = 'card', $classes = 'w-full h-full object-cover') {
    if (has_post_thumbnail()) {
        echo '<img class="' . $classes . '" src="' . esc_url(get_the_post_thumbnail_url(null, $size)) . '" alt="' . esc_attr(get_the_title()) . '">';
    } else {
        echo '<div class="w-full h-full bg-surface-container-high flex items-center justify-center">';
        echo '<span class="material-symbols-outlined text-6xl" style="color:#dfc0b7;font-size:4rem;">phone_iphone</span>';
        echo '</div>';
    }
}

/* ── Excerpt Length ── */
add_filter('excerpt_length', fn() => 20);
add_filter('excerpt_more', fn() => '');
