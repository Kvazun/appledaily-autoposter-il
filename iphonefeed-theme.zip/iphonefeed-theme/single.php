<?php get_header(); ?>

<?php while (have_posts()): the_post(); ?>

<main class="max-w-screen-xl mx-auto px-6 md:px-12 pt-10 pb-20">

    <!-- Breadcrumb -->
    <nav class="flex items-center gap-2 font-label text-[10px] uppercase tracking-widest text-on-surface-variant/50 mb-10">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="hover:text-primary transition-colors">Главная</a>
        <span>/</span>
        <?php $cats = get_the_category(); if (!empty($cats)): ?>
        <a href="<?php echo esc_url(get_category_link($cats[0]->term_id)); ?>" class="hover:text-primary transition-colors">
            <?php echo esc_html($cats[0]->name); ?>
        </a>
        <span>/</span>
        <?php endif; ?>
        <span class="text-on-surface/40 truncate max-w-[200px]"><?php the_title(); ?></span>
    </nav>

    <div class="grid grid-cols-1 lg:grid-cols-12 gap-14">

        <!-- Article -->
        <article class="lg:col-span-8">

            <!-- Category + read time -->
            <div class="flex items-center gap-3 mb-6">
                <?php if (!empty($cats)): ?>
                <a href="<?php echo esc_url(get_category_link($cats[0]->term_id)); ?>"
                   class="bg-secondary-container text-on-secondary-container px-3 py-1 rounded-full font-label text-[10px] uppercase tracking-widest hover:bg-primary hover:text-white transition-colors">
                    <?php echo esc_html($cats[0]->name); ?>
                </a>
                <?php endif; ?>
                <span class="text-on-surface-variant/50 font-label text-[10px] uppercase tracking-widest">
                    <?php echo iphonefeed_reading_time(); ?> чтения
                </span>
            </div>

            <!-- Title -->
            <h1 class="font-headline italic text-4xl md:text-6xl leading-[1] tracking-tight mb-8 text-on-surface">
                <?php the_title(); ?>
            </h1>

            <!-- Meta -->
            <div class="flex items-center gap-4 mb-10 pb-8 border-b border-outline-variant/20">
                <div class="w-10 h-10 rounded-full overflow-hidden bg-surface-container shrink-0">
                    <?php echo get_avatar(get_the_author_meta('ID'), 40, '', '', ['class' => 'w-full h-full object-cover']); ?>
                </div>
                <div>
                    <p class="font-label text-xs uppercase tracking-wider font-bold"><?php the_author(); ?></p>
                    <p class="font-label text-[10px] text-on-surface-variant/60 uppercase tracking-widest">
                        <?php echo get_the_date('j F Y'); ?>
                    </p>
                </div>
            </div>

            <!-- Hero image -->
            <?php if (has_post_thumbnail()): ?>
            <div class="aspect-video mb-10 overflow-hidden bg-surface-container">
                <img class="w-full h-full object-cover"
                     src="<?php echo esc_url(get_the_post_thumbnail_url(null, 'hero')); ?>"
                     alt="<?php echo esc_attr(get_the_title()); ?>">
            </div>
            <?php endif; ?>

            <!-- Content -->
            <div class="prose prose-lg max-w-none font-body text-on-surface leading-relaxed
                        [&_h2]:font-headline [&_h2]:text-3xl [&_h2]:italic [&_h2]:mt-12 [&_h2]:mb-4
                        [&_h3]:font-headline [&_h3]:text-2xl [&_h3]:mt-8 [&_h3]:mb-3
                        [&_p]:mb-6 [&_p]:text-on-surface-variant [&_p]:text-base [&_p]:leading-[1.9]
                        [&_a]:text-primary [&_a]:underline
                        [&_img]:w-full [&_img]:my-8
                        [&_blockquote]:border-l-4 [&_blockquote]:border-primary [&_blockquote]:pl-6 [&_blockquote]:italic [&_blockquote]:text-on-surface-variant">
                <?php the_content(); ?>
            </div>

            <!-- Tags -->
            <?php $tags = get_the_tags(); if ($tags): ?>
            <div class="flex flex-wrap gap-2 mt-10 pt-8 border-t border-outline-variant/20">
                <?php foreach ($tags as $tag): ?>
                <a href="<?php echo esc_url(get_tag_link($tag->term_id)); ?>"
                   class="bg-surface-container px-3 py-1 font-label text-[10px] uppercase tracking-widest text-on-surface-variant hover:bg-primary hover:text-white transition-colors">
                    #<?php echo esc_html($tag->name); ?>
                </a>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

        </article>

        <!-- Sidebar -->
        <aside class="lg:col-span-4">
            <div class="sticky top-28 flex flex-col gap-8">

                <!-- Ad -->
                <div class="ad-slot w-full h-[300px]">
                    <span class="ad-label uppercase">Advertisement</span>
                    <div class="text-[10px] text-on-surface-variant/30 uppercase tracking-[0.2em]">300×300</div>
                </div>

                <!-- Recent posts -->
                <div>
                    <h3 class="font-headline text-2xl italic mb-6 pb-3 border-b border-outline-variant/20">Читайте также</h3>
                    <?php
                    $related = new WP_Query(['posts_per_page' => 4, 'post__not_in' => [get_the_ID()]]);
                    while ($related->have_posts()): $related->the_post();
                    ?>
                    <article class="group flex gap-4 mb-6 pb-6 border-b border-outline-variant/10 last:border-0 last:mb-0 last:pb-0">
                        <div class="w-16 h-16 shrink-0 bg-surface-container overflow-hidden">
                            <?php if (has_post_thumbnail()): ?>
                            <img class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                                 src="<?php echo esc_url(get_the_post_thumbnail_url(null, 'thumbnail')); ?>"
                                 alt="<?php echo esc_attr(get_the_title()); ?>">
                            <?php else: ?>
                            <div class="w-full h-full bg-surface-container-high flex items-center justify-center">
                                <span style="font-family:'Material Symbols Outlined';font-size:1.5rem;color:#dfc0b7;">phone_iphone</span>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div>
                            <h4 class="font-headline text-base leading-tight group-hover:text-primary transition-colors">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h4>
                            <span class="font-label text-[10px] text-on-surface-variant/40 uppercase tracking-widest mt-1 block">
                                <?php echo get_the_date('j M'); ?>
                            </span>
                        </div>
                    </article>
                    <?php endwhile; wp_reset_postdata(); ?>
                </div>

                <!-- Ad 2 -->
                <div class="ad-slot w-full h-[250px]">
                    <span class="ad-label uppercase">Advertisement</span>
                    <div class="text-[10px] text-on-surface-variant/30 uppercase tracking-[0.2em]">300×250</div>
                </div>

            </div>
        </aside>

    </div>
</main>

<?php endwhile; ?>

<?php get_footer(); ?>
