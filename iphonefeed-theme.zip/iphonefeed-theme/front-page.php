<?php get_header(); ?>

<?php
// Hero: latest post
$hero_q = new WP_Query(['posts_per_page' => 1]);
$hero   = $hero_q->have_posts() ? ($hero_q->the_post() ?: true) : false;
?>

<main class="max-w-screen-2xl mx-auto px-6 md:px-12 pt-10">

<?php if ($hero): ?>
<!-- ═══ HERO ═══ -->
<section class="grid grid-cols-1 lg:grid-cols-12 gap-10 mb-24">

    <!-- Text -->
    <div class="lg:col-span-7 flex flex-col justify-center order-2 lg:order-1">
        <div class="flex items-center gap-3 mb-6">
            <?php $cats = get_the_category(); if (!empty($cats)): ?>
            <a href="<?php echo esc_url(get_category_link($cats[0]->term_id)); ?>"
               class="bg-secondary-container text-on-secondary-container px-3 py-1 rounded-full font-label text-[10px] uppercase tracking-widest hover:bg-primary hover:text-white transition-colors">
                <?php echo esc_html($cats[0]->name); ?>
            </a>
            <?php endif; ?>
            <span class="text-on-surface-variant/60 font-label text-[10px] uppercase tracking-widest">
                <?php echo iphonefeed_reading_time(); ?> чтения
            </span>
        </div>

        <h1 class="font-headline italic text-5xl md:text-7xl lg:text-8xl leading-[0.92] tracking-tighter mb-8 text-on-surface">
            <a href="<?php the_permalink(); ?>" class="hover:text-primary transition-colors">
                <?php the_title(); ?>
            </a>
        </h1>

        <p class="font-body text-lg text-on-surface-variant max-w-xl leading-relaxed mb-10">
            <?php echo wp_trim_words(get_the_excerpt(), 30, '…'); ?>
        </p>

        <div class="flex items-center gap-4">
            <div class="w-11 h-11 rounded-full overflow-hidden bg-surface-container shrink-0">
                <?php echo get_avatar(get_the_author_meta('ID'), 44, '', '', ['class' => 'w-full h-full object-cover']); ?>
            </div>
            <div>
                <p class="font-label text-xs uppercase tracking-wider font-bold"><?php the_author(); ?></p>
                <p class="font-label text-[10px] text-on-surface-variant/60 uppercase tracking-widest"><?php echo get_the_date('j F Y'); ?></p>
            </div>
        </div>
    </div>

    <!-- Image -->
    <div class="lg:col-span-5 order-1 lg:order-2">
        <a href="<?php the_permalink(); ?>">
        <div class="relative h-[360px] lg:h-[640px] w-full bg-surface-container group overflow-hidden">
            <?php if (has_post_thumbnail()): ?>
            <img class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                 src="<?php echo esc_url(get_the_post_thumbnail_url(null, 'hero')); ?>"
                 alt="<?php echo esc_attr(get_the_title()); ?>">
            <?php else: ?>
            <div class="w-full h-full bg-surface-container-high flex items-center justify-center">
                <span style="font-family:'Material Symbols Outlined';font-size:6rem;color:#dfc0b7;">phone_iphone</span>
            </div>
            <?php endif; ?>
            <div class="absolute inset-0 bg-primary/5 mix-blend-multiply"></div>
        </div>
        </a>
    </div>

</section>
<?php wp_reset_postdata(); endif; ?>

<!-- ═══ THE LATEST ═══ -->
<?php
$latest_q = new WP_Query(['posts_per_page' => 4, 'offset' => 1]);
if ($latest_q->have_posts()):
?>
<section class="mb-20">
    <div class="flex justify-between items-end mb-10 border-b border-outline-variant/20 pb-4">
        <h2 class="font-headline text-4xl italic tracking-tight">Свежее</h2>
        <a href="<?php echo esc_url(get_permalink(get_option('page_for_posts'))); ?>"
           class="font-label text-xs uppercase tracking-widest text-primary flex items-center gap-2 group">
            Все новости
            <span style="font-family:'Material Symbols Outlined';font-size:1rem;transition:transform .2s;">arrow_forward</span>
        </a>
    </div>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-14">
        <?php while ($latest_q->have_posts()): $latest_q->the_post(); ?>
        <article class="group">
            <a href="<?php the_permalink(); ?>">
                <div class="aspect-[4/3] bg-surface-container mb-5 overflow-hidden">
                    <?php if (has_post_thumbnail()): ?>
                    <img class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                         src="<?php echo esc_url(get_the_post_thumbnail_url(null, 'card')); ?>"
                         alt="<?php echo esc_attr(get_the_title()); ?>">
                    <?php else: ?>
                    <div class="w-full h-full bg-surface-container-high flex items-center justify-center">
                        <span style="font-family:'Material Symbols Outlined';font-size:3rem;color:#dfc0b7;">phone_iphone</span>
                    </div>
                    <?php endif; ?>
                </div>
                <?php iphonefeed_category_badge(); ?>
                <h3 class="font-headline text-2xl leading-tight mb-3 group-hover:text-primary transition-colors duration-200">
                    <?php the_title(); ?>
                </h3>
                <p class="font-body text-sm text-on-surface-variant line-clamp-2">
                    <?php echo wp_trim_words(get_the_excerpt(), 18, '…'); ?>
                </p>
            </a>
        </article>
        <?php endwhile; wp_reset_postdata(); ?>
    </div>
</section>
<?php endif; ?>

<!-- ═══ MID AD ═══ -->
<div class="w-full flex justify-center mb-14">
    <div class="ad-slot w-full max-w-[728px] h-[90px]">
        <span class="ad-label uppercase">Advertisement</span>
        <div class="text-[10px] text-on-surface-variant/30 uppercase tracking-[0.2em]">728×90</div>
    </div>
</div>

<!-- ═══ MORE POSTS (5-12) ═══ -->
<?php
$more_q = new WP_Query(['posts_per_page' => 8, 'offset' => 5]);
if ($more_q->have_posts()):
?>
<section class="py-16 -mx-6 md:-mx-12 px-6 md:px-12 bg-surface-container">
    <div class="max-w-screen-2xl mx-auto">
        <div class="flex justify-between items-end mb-10 border-b border-outline-variant/20 pb-4">
            <h2 class="font-headline text-4xl italic tracking-tight">Ещё новости</h2>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-10">
            <?php while ($more_q->have_posts()): $more_q->the_post(); ?>
            <article class="group flex gap-4 items-start bg-surface p-5 editorial-shadow hover:border-b-2 hover:border-primary transition-all duration-200">
                <div class="w-20 h-20 shrink-0 bg-surface-container overflow-hidden">
                    <?php if (has_post_thumbnail()): ?>
                    <img class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                         src="<?php echo esc_url(get_the_post_thumbnail_url(null, 'thumbnail')); ?>"
                         alt="<?php echo esc_attr(get_the_title()); ?>">
                    <?php else: ?>
                    <div class="w-full h-full bg-surface-container-high flex items-center justify-center">
                        <span style="font-family:'Material Symbols Outlined';font-size:2rem;color:#dfc0b7;">phone_iphone</span>
                    </div>
                    <?php endif; ?>
                </div>
                <div>
                    <?php iphonefeed_category_badge(); ?>
                    <h4 class="font-headline text-lg leading-tight group-hover:text-primary transition-colors">
                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                    </h4>
                    <span class="font-label text-[10px] text-on-surface-variant/40 uppercase tracking-widest mt-1 block">
                        <?php echo get_the_date('j M Y'); ?>
                    </span>
                </div>
            </article>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- ═══ NEWSLETTER ═══ -->
<section class="my-20 bg-primary px-8 md:px-20 py-16 text-on-primary grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
    <div>
        <h2 class="font-headline text-5xl italic leading-none mb-6">iPhoneFeed Daily</h2>
        <p class="font-body text-lg text-on-primary/80 max-w-md leading-relaxed">
            Лучшие новости об Apple и iPhone — каждое утро на почту. Без спама, только важное.
        </p>
    </div>
    <form class="flex flex-col md:flex-row gap-4" method="post" action="#">
        <input class="flex-grow bg-primary-container border-none text-on-primary placeholder:text-on-primary/50 px-6 py-4 font-label text-sm uppercase tracking-widest focus:outline-none focus:ring-2 focus:ring-white/30"
               placeholder="ВАШ@EMAIL.COM" type="email" name="email">
        <button class="bg-on-primary text-primary px-10 py-4 font-label font-bold text-xs uppercase tracking-[0.2em] hover:bg-surface-container-low transition-colors shrink-0"
                type="submit">Подписаться</button>
    </form>
</section>

</main>

<?php get_footer(); ?>
