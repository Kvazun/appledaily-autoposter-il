<!DOCTYPE html>
<html <?php language_attributes(); ?> class="light">
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php wp_head(); ?>
</head>
<body <?php body_class('bg-surface text-on-surface font-body'); ?>>
<?php wp_body_open(); ?>

<!-- Top Leaderboard Ad Slot -->
<div class="w-full flex justify-center pt-4 bg-surface">
    <div class="ad-slot w-full max-w-[728px] h-[90px] mx-4">
        <span class="ad-label uppercase">Advertisement</span>
        <div class="text-[10px] text-on-surface-variant/30 uppercase tracking-[0.2em]">728×90</div>
    </div>
</div>

<!-- Sticky Header -->
<header class="sticky top-0 z-50 glass-header border-b border-outline-variant/20">
    <nav class="flex justify-between items-center w-full px-6 md:px-8 py-4 max-w-screen-2xl mx-auto">
        <div class="flex items-center gap-8 md:gap-12">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="text-2xl md:text-3xl font-bold font-headline text-on-surface tracking-tighter">
                <?php bloginfo('name'); ?>
            </a>
            <div class="hidden md:flex gap-6">
                <?php
                $cats = get_categories(['number' => 5, 'hide_empty' => true]);
                foreach ($cats as $cat):
                    $active = (is_category($cat->term_id)) ? 'text-primary border-b-2 border-primary pb-1' : 'text-on-surface/60 hover:text-primary transition-colors duration-300';
                ?>
                <a class="<?php echo $active; ?> font-label uppercase tracking-widest text-xs" href="<?php echo esc_url(get_category_link($cat->term_id)); ?>">
                    <?php echo esc_html($cat->name); ?>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="flex items-center gap-4">
            <a href="<?php echo esc_url(get_search_link()); ?>" class="material-symbols-outlined text-on-surface-variant hover:text-primary transition-colors" style="font-family:'Material Symbols Outlined';font-size:24px;text-decoration:none;">search</a>
        </div>
    </nav>
</header>
