<?php get_header(); ?>

<main class="max-w-screen-2xl mx-auto px-6 md:px-12 pt-10 pb-20">

    <!-- Page Title -->
    <div class="mb-12 border-b border-outline-variant/20 pb-6">
        <?php if (is_category()): ?>
        <span class="font-label text-xs uppercase tracking-[0.3em] text-primary font-bold block mb-2">Категория</span>
        <h1 class="font-headline text-5xl italic"><?php single_cat_title(); ?></h1>
        <?php elseif (is_search()): ?>
        <span class="font-label text-xs uppercase tracking-[0.3em] text-primary font-bold block mb-2">Поиск</span>
        <h1 class="font-headline text-5xl italic">«<?php the_search_query(); ?>»</h1>
        <?php elseif (is_archive()): ?>
        <span class="font-label text-xs uppercase tracking-[0.3em] text-primary font-bold block mb-2">Архив</span>
        <h1 class="font-headline text-5xl italic"><?php the_archive_title(); ?></h1>
        <?php else: ?>
        <h1 class="font-headline text-5xl italic">Все новости</h1>
        <?php endif; ?>
    </div>

    <?php if (have_posts()): ?>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-14">
        <?php while (have_posts()): the_post(); ?>
        <article class="group">
            <a href="<?php the_permalink(); ?>">
                <div class="aspect-[4/3] bg-surface-container mb-5 overflow-hidden">
                    <?php if (has_post_thumbnail()): ?>
                    <img class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                         src="<?php echo esc_url(get_the_post_thumbnail_url(null, 'card')); ?>"
                         alt="<?php echo esc_attr(get_the_title()); ?>">
                    <?php else: ?>
                    <div class="w-full h-full bg-surface-container-high flex items-center justify-center">
                        <span style="font-family:'Material Symbols Outlined';font-size:4rem;color:#dfc0b7;">phone_iphone</span>
                    </div>
                    <?php endif; ?>
                </div>
                <?php iphonefeed_category_badge(); ?>
                <h2 class="font-headline text-2xl leading-tight mb-3 group-hover:text-primary transition-colors duration-200">
                    <?php the_title(); ?>
                </h2>
                <p class="font-body text-sm text-on-surface-variant line-clamp-2 mb-4">
                    <?php echo wp_trim_words(get_the_excerpt(), 20, '…'); ?>
                </p>
                <span class="font-label text-[10px] text-on-surface-variant/40 uppercase tracking-widest">
                    <?php echo get_the_date('j F Y'); ?> &bull; <?php echo iphonefeed_reading_time(); ?> чтения
                </span>
            </a>
        </article>
        <?php endwhile; ?>
    </div>

    <!-- Pagination -->
    <div class="flex justify-center mt-16">
        <?php
        echo paginate_links([
            'prev_text' => '&larr; Новее',
            'next_text' => 'Старше &rarr;',
            'before_page_number' => '',
            'type' => 'list',
        ]);
        ?>
    </div>

    <?php else: ?>
    <p class="font-body text-on-surface-variant text-center py-20">Записи не найдены.</p>
    <?php endif; ?>

</main>

<?php get_footer(); ?>
